# project-5-serverless-cross-region-dr

[project-1-serverless-cross-region-dr.md](https://github.com/user-attachments/files/20428469/project-1-serverless-cross-region-dr.md)
